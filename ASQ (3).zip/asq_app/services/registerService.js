var express = require('express');
var userModel = require('../models/userModel');
