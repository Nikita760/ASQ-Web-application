var express = require('express');
var user =  require('../models/userModel.js');
var router = express.Router();

router.post('/login',function (req, res){

});
